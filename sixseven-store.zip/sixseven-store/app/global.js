/* Reset */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI",
    sans-serif;
  background: #f4f4f5;
  color: #111827;
}

.app-root {
  min-height: 100vh;
}

/* Header */
.store-header {
  background: #111827;
  color: #f9fafb;
  padding: 16px 20px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 12px;
  justify-content: space-between;
}

.store-title {
  font-size: 1.3rem;
  font-weight: 700;
  letter-spacing: 1px;
}

.brand-badge {
  font-size: 0.75rem;
  opacity: 0.8;
}

.search-wrapper {
  flex: 1;
  max-width: 330px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.search-input {
  flex: 1;
  padding: 8px 10px;
  border-radius: 999px;
  border: 1px solid #374151;
  background: #111827;
  color: #f9fafb;
  font-size: 0.85rem;
}

.search-input::placeholder {
  color: #9ca3af;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 0.8rem;
}

.chip {
  padding: 4px 10px;
  border-radius: 999px;
  border: 1px solid #4b5563;
  background: #1f2937;
}

/* Main */
.store-main {
  max-width: 1100px;
  margin: 20px auto 40px;
  padding: 0 16px;
}

/* Info bar */
.info-bar {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 18px;
  font-size: 0.8rem;
  color: #4b5563;
}

.info-highlight {
  font-weight: 600;
  color: #111827;
}

/* Product grid */
.product-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
  gap: 16px;
}

/* Product card */
.product-card {
  background: #ffffff;
  border-radius: 14px;
  padding: 10px;
  box-shadow: 0 8px 18px rgba(15, 23, 42, 0.08);
  display: flex;
  flex-direction: column;
  gap: 8px;
  transition: transform 0.13s ease, box-shadow 0.13s ease;
}

.product-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 14px 28px rgba(15, 23, 42, 0.12);
}

.product-img {
  width: 100%;
  aspect-ratio: 4/5;
  border-radius: 10px;
  background: linear-gradient(135deg, #e5e7eb, #d1d5db);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.75rem;
  color: #6b7280;
  margin-bottom: 4px;
}

.product-brand {
  font-size: 0.7rem;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: #9ca3af;
}

.product-name {
  font-size: 0.9rem;
  font-weight: 600;
  color: #111827;
}

.product-meta {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-top: 4px;
}

.product-price {
  font-weight: 700;
  color: #111827;
}

.product-tag {
  font-size: 0.7rem;
  padding: 2px 7px;
  border-radius: 999px;
  background: #eff6ff;
  color: #1d4ed8;
}

/* Card actions */
.card-actions {
  display: flex;
  margin-top: 8px;
  gap: 8px;
}

.btn {
  border: none;
  border-radius: 999px;
  padding: 7px 10px;
  font-size: 0.75rem;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  transition: background 0.15s ease, transform 0.1s ease, box-shadow 0.1s ease;
}

.btn:active {
  transform: scale(0.97);
}

.btn-primary {
  flex: 1;
  background: #111827;
  color: #f9fafb;
  box-shadow: 0 6px 12px rgba(15, 23, 42, 0.25);
}

.btn-primary:hover {
  background: #020617;
}

.btn-ghost {
  width: 40px;
  background: #f3f4f6;
  color: #111827;
}

.btn-ghost.active {
  background: #fee2e2;
  color: #b91c1c;
}

/* Footer summary */
.footer-summary {
  margin-top: 24px;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  justify-content: space-between;
  font-size: 0.8rem;
  color: #4b5563;
}

.badge {
  padding: 4px 8px;
  border-radius: 999px;
  background: #e5e7eb;
}

/* Responsive */
@media (max-width: 640px) {
  .store-header {
    align-items: flex-start;
  }
  .search-wrapper {
    order: 3;
    width: 100%;
  }
}